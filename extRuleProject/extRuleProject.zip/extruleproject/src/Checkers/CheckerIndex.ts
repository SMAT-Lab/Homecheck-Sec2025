import { ForeachArgsCheck } from "./ForEachArgsCheck";

// 新增文件级的checker，需要在此处注册
export const file2CheckRuleMap: Map<string, any> = new Map();
file2CheckRuleMap.set("@extrulesproject/foreach-args-check", ForeachArgsCheck);

// 新增项目级checker，需要在此处注册
export const project2CheckRuleMap: Map<string, any> = new Map();